<!DOCTYPE html>
<html>
<head>
	<title>muahang</title>
	 <title>shopgame</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/add_shop.css">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">
</head>
	<body>
		<!DOCTYPE html>
<html lang="en">
  <head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>eCommerce Product Detail</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">

  </head>

  <body>
	
	<div class="container">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="http://sv1.upsieutoc.com/2017/05/05/17947795_1259777634072196_5852397358939111424_n.png" alt="Sniper Ghost Warrior 3" /></div>
						</div>
						
					</div>
					<div class="details col-md-6">
						<h3 class="product-title">Tên game: Sniper Ghost Warrior 3 </h3>
						<div class="rating">
							<div class="stars">
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<span class="review-no">Hình Thức Chơi Được: Offline</span>
						</div>
						<p class="product-description"></p>
						<h4 class="price">✪ Giá: 
- 50k ( chuyển khoản)
- 60k (thẻ cào Vina hoặc Mobi hoặc Viettel)
</h4>
						<pre class="vote">✪ Link: 
- Game: https://www.fshare.vn/folder/9XN5JYYPB7S3

✪ Điều kiện: 
- Tải link game ở trên trước, giải nén ra và để vào nơi mà bạn muốn cài đặt
- Cần Teamviewer: https://www.teamviewer.com/vi/
- Bộ cài Steam: http://store.steampowered.com/about/

✪ Cấu hình yêu cầu:
- OS: Windows 7/8/10 (64-bit versions) 
- Processor: i3 3240 3.4 GHz or AMD FX-6350 3.9 GHz
- Memory: 8 GB
- Video Card: NVIDIA GeForce GTX 660 2GB or AMD Radeon HD 7850 2GB
- Disk space: 50 GB

✪ Inbox nếu bác bạn muốn active

✪ Lưu ý: 
- một ngày denuvo chỉ cho active được 5 người, 
cho nên các bác nào không active được ngay vui lòng quay lại sau.

- vui lòng đừng update win khi mới active vì khi win update sẽ phải active lại,
 những game mới đông người có thể sẽ phải chờ vài hôm
 vì số người đặt active còn nhiều và mình chưa làm được ngay 
 ( bác nào cần tắt update win mà không biết có thể báo lại để mình hỗ trợ )


Mình sẽ support update, cài lại game cho các bạn nếu bị mất dữ liệu hư ổ cứng
 ….. miễn phí trong vòng 1 năm kể từ ngày active</pre>
						<h5 class="sizes">
							<span class="size" data-toggle="tooltip" title="small"></span>
							<span class="size" data-toggle="tooltip" title="medium"></span>
							<span class="size" data-toggle="tooltip" title="large"></span>
							<span class="size" data-toggle="tooltip" title="xtra large"></span>
						</h5>
						<h5 class="colors">
							<span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
							<span class="color green"></span>
							<span class="color blue"></span>
						</h5>
						<div class="action">
							<button class="add-to-cart btn btn-default" type="button">Các Bạn Mua Hàng Bằng Cách Đặt yêu cầu vào Gmail này : Phantuanw.o.t@gmail.com</button>
							<button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  </body>
</html>

	</body>
</html>