<!DOCTYPE html>
<html>
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/add_shop.css">
  <script type="text/javascript" src="js/add_shop.js"></script>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery1.js"></script>
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/wowslider.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
  <body>
      <div class="container">
      <div class="row">
      <div class="col-md-5  toppad  pull-right col-md-offset-3 ">
           <A href="edit.html" >Edit Profile</A>

        <A href="edit.html" >Logout</A>
       <br>
<p class=" text-info">May 05,2017,11:42 pm </p>
      </div>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Thông Tin Admin Web</h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="http://sv1.upsieutoc.com/2017/05/05/14333701_662218187279270_9077193742386259597_n.jpg" class="img-circle img-responsive"> </div>
                
                <!--<div class="col-xs-10 col-sm-10 hidden-md hidden-lg"> <br>
                  <dl>
                    <dt>DEPARTMENT:</dt>
                    <dd>Administrator</dd>
                    <dt>HIRE DATE</dt>
                    <dd>11/12/2013</dd>
                    <dt>DATE OF BIRTH</dt>
                       <dd>11/12/2013</dd>
                    <dt>GENDER</dt>
                    <dd>Male</dd>
                  </dl>
                </div>-->
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Tên Admin:</td>
                        <td>Phan Kim Tuân</td>
                      </tr>
                      <tr>
                        <td>Ngày Sinh:</td>
                        <td>29/01/1998</td>
                      </tr>
                      <tr>
                        <td>Date of Birth</td>
                        <td>29/01/1998</td>
                      </tr>
                   
                         <tr>
                             <tr>
                        <td>Học vấn</td>
                        <td>Sinh viên công nghệ thông tin</td>
                      </tr>
                        <tr>
                        <td>Trường học</td>
                        <td>Đại Học Công Nghệ Thông Tin Và Truyền Thông</td>
                      </tr>
                      <tr>
                        <td>Email</td>
                        <td><a href="Phantuanw.o.t@gmail.com">Phantuanw.o.t@gmail.com</a></td>
                      </tr>
                        <td>Phone Number</td>
                        <td>01654665693<br><br>
                        </td>
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  <a href="https://id.zalo.me/account/login?continue=https%3A%2F%2Fchat.zalo.me%2F" class="btn btn-primary">Liên Hệ Với Tôi</a>
                  <a href="https://id.zalo.me/account/login?continue=https%3A%2F%2Fchat.zalo.me%2F" class="btn btn-primary">Liên Hệ Với Đội Ngũ Hỗ Trợ</a>
                </div>
              </div>
            </div>
                 <div class="panel-footer">
                        <a data-original-title="Broadcast Message" data-toggle="tooltip" type="button" class="btn btn-sm btn-primary"><i class="glyphicon glyphicon-envelope"></i></a>
                        <span class="pull-right">
                            <a href="edit.html" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a data-original-title="Remove this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                        </span>
                    </div>
            
          </div>
        </div>
      </div>
    </div>
  </body >
</html>