$(document).ready(function(){
	$(".info").hide().fadeIn(1500);
	})