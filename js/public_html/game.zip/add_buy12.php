<!DOCTYPE html>
<html>
<head>
	<title>muahang</title>
	 <title>shopgame</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/add_shop.css">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css">
</head>
	<body>
		<!DOCTYPE html>
<html lang="en">
  <head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>eCommerce Product Detail</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">

  </head>

  <body>
	
	<div class="container">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="http://sv1.upsieutoc.com/2017/05/05/15548518_1087730881336678_6513747027451445248_n.png" alt="Battlefield 1" /></div>
						</div>
						
					</div>
					<div class="details col-md-6">
						<h3 class="product-title">Tên game: Battlefield 1</h3>
						<div class="rating">
							<div class="stars">
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<span class="review-no">Hình Thức Chơi Được: Offline + Online</span>
						</div>
						<p class="product-description"></p>
						<h4 class="price">✪ Giá: 
- 120k (chuyển khoản)
- 150k (thẻ cào Vina hoặc Mobi hoặc Viettel)</h4>
						<pre class="vote">✪ Account 2:
- Là account cũ
- Không bị ban hay hack cheat
- Online 100%
- KHÔNG thay đổi được thông tin, email, mật khẩu

✪ Support:
- Hỗ trợ đổi account ít nhất 3 tháng đầu,
sau 3 tháng mình sẽ support đến khi nào ko đổi account được nữa thì thôi
- Active phần offline (nếu có) trong vòng 1 năm

✪ Lưu ý:
- Test thử phần online, không nên cày kéo ngay
- Nếu khoảng 5-7 ngày mà account xài bình thường, 
không bị đổi pass hoặc có người lgin, bạn có thể dùng acc để chơi thoải mái

- Nếu bị tình trạng đăng nhập từ người khác liên tục trong vòng 2-3 ngày, 
chụp hình và liên hệ mình để đổi acc
- Nếu bị lỗi hoặc bị mât account, chụp hình và báo mình để đổi acc mới

✪ Inbox nếu bạn muốn đặt mua</pre>
						<h5 class="sizes">
							<span class="size" data-toggle="tooltip" title="small"></span>
							<span class="size" data-toggle="tooltip" title="medium"></span>
							<span class="size" data-toggle="tooltip" title="large"></span>
							<span class="size" data-toggle="tooltip" title="xtra large"></span>
						</h5>
						<h5 class="colors">
							<span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
							<span class="color green"></span>
							<span class="color blue"></span>
						</h5>
						<div class="action">
							<button class="add-to-cart btn btn-default" type="button">Các Bạn Mua Hàng Bằng Cách Đặt yêu cầu vào Gmail này : Phantuanw.o.t@gmail.com</button>
							<button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  </body>
</html>

	</body>
</html>